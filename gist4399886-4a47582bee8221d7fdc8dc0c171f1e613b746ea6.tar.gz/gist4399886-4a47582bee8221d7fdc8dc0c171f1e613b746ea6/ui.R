require(shiny)

shinyUI(pageWithSidebar(
  headerPanel("Example 2: pie chart"),
  sidebarPanel(
    numericInput("Cities","Number of cities:", 2)
  ),
  mainPanel(
    htmlOutput("gvis")
    )
  )
)