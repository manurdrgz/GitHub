## Diego de Castillo, Markus Gesmann, February 2013
require(shiny)
require(googleVis)

shinyServer(function(input, output) {
  myCities <- reactive({
     input$Cities
  })
  
  output$gvis <- renderGvis({   
     myData <- head(CityPopularity, myCities())
     gvisPieChart(myData)  
  })
})
